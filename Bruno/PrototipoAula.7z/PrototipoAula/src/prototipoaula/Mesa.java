/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototipoaula;

/**
 *
 * @author Bruno
 */
public class Mesa {
    private int idmesa;
    private int capacidade;
    private int numeromesa;

    /**
     * @return the idmesa
     */
    public int getIdmesa() {
        return idmesa;
    }

    /**
     * @param idmesa the idmesa to set
     */
    public void setIdmesa(int idmesa) {
        this.idmesa = idmesa;
    }

    /**
     * @return the capacidade
     */
    public int getCapacidade() {
        return capacidade;
    }

    /**
     * @param capacidade the capacidade to set
     */
    public void setCapacidade(int capacidade) {
        this.capacidade = capacidade;
    }

    /**
     * @return the numeromesa
     */
    public int getNumeromesa() {
        return numeromesa;
    }

    /**
     * @param numeromesa the numeromesa to set
     */
    public void setNumeromesa(int numeromesa) {
        this.numeromesa = numeromesa;
    }

}
