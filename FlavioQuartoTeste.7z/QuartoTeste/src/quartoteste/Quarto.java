/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quartoteste;

/**
 *
 * @author usrlab25
 */
public class Quarto {
    public int numQuarto;
    public int nCamas;
    public char tipoCama;
    public int andarQuarto;
    //public String areaQuarto;
    public char categoria;
    public boolean luxo;

//    public Quarto(int numQuarto, int nCamas, String tipoCama, int andarQuarto, double areaQuarto) {
//        this.numQuarto = numQuarto;
//        this.nCamas = nCamas;
//        this.tipoCama = tipoCama;
//        this.andarQuarto = andarQuarto;
//        this.areaQuarto = areaQuarto;
//    }
//
//    public int getNumQuarto() {
//        return numQuarto;
//    }
//
//    public void setNumQuarto(int numQuarto) {
//        this.numQuarto = numQuarto;
//    }
//    
//    public int getnCamas() {
//        return nCamas;
//    }
//
//    public String getTipoCama() {
//        return tipoCama;
//    }
//
//    public int getAndarQuarto() {
//        return andarQuarto;
//    }
//
//    public double getAreaQuarto() {
//        return areaQuarto;
//    }
//
//    public void setnCamas(int nCamas) {
//        this.nCamas = nCamas;
//    }
//
//    public void setTipoCama(String tipoCama) {
//        this.tipoCama = tipoCama;
//    }
//
//    public void setAndarQuarto(int andarQuarto) {
//        this.andarQuarto = andarQuarto;
//    }
//
//    public void setAreaQuarto(double areaQuarto) {
//        this.areaQuarto = areaQuarto;
//    }
//    
//    @Override
//    public String toString(){
//        return "Quarto numero "+numQuarto+"\nQuantidade de camas: "+nCamas+"\nTipo de cama: "+tipoCama+"\nAndar: "+andarQuarto+"\nArea total: "+areaQuarto+"m²";
//    }
}
