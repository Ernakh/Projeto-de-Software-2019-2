/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package frigobarfinal;

/**
 *
 * @author Joey
 */
public class item {
    public String nome;
    public String preco;
    public String quantidade;
    




}
